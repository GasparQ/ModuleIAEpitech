﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    [System.Serializable]
    public class Player {
        public GameObject prefab;
        public string name;
    }
    public TextMeshProUGUI text;
    public float wait = 2f;
    public Board board;
    public Singer singer;
    [SerializeField]
    private string filename;
    [SerializeField]
    private Player[] players;
    private bool playing = false;
    private GameObject[] m_players;

    private int turn = 0;
    private int score = 0;
    private int shadow = 0;

    public int Turn { get => turn; set => turn = value; }
    public int Score { get => score; set => score = value; }
    public int Shadow { get => shadow; set => shadow = value; }

    enum DataOffset : int
    {
        TURN = 0,
        SCORE = 1,
        SHADOW = 2,
        LOCK1 = 3,
        LOCK2 = 4,
        BLACK = 5,
        BROWN = 8,
        GRAY = 11,
        PINK = 14,
        PURPLE = 17,
        RED = 20,
        WHITE = 23
    }
    // Start is called before the first frame update
    void Start()
    {
        //GeneratePlayerMap();
        InitPlayers();
        StartCoroutine("StartGame");
    }

    private void InitPlayers()
    {
        m_players = new GameObject[players.Length];
        for (int i = 0; i < players.Length; i++)
        {
            m_players[i] = Instantiate(players[i].prefab);
        }
    }

    //private void GeneratePlayerMap()
    //{
    //    foreach (var player in players)
    //    {
    //        m_players[player.name] = player.prefab;
    //    }
    //}

    void ParseFile()
    {
        string[] lines = System.IO.File.ReadAllLines(filename);
        foreach (var line in lines)
        {
            print(line);
        }
    }

    void ParseLine(string line)
    {
        var args = line.Split(',');
        turn = int.Parse(args[(int)DataOffset.TURN]);
        score = int.Parse(args[(int)DataOffset.SCORE]);
        singer.MoveSinger(score);
        shadow = int.Parse(args[(int)DataOffset.SHADOW]);
        board.ActivateShadow(shadow);
        text.text = "Turn : " + args[(int)DataOffset.TURN];

        for (int i = 0; i < m_players.Length; i++)
        {
            int index = (int)DataOffset.BLACK + i * 3;
            int pos = int.Parse(args[index]);
            int suspect = int.Parse(args[index + 2]);
            board.MovePlayer(m_players[i], pos);
            if (suspect != 0) m_players[i].GetComponent<Character>().Clean();
        }
    }

    IEnumerator StartGame()
    {
        playing = true;
        string[] lines = System.IO.File.ReadAllLines(filename);
        foreach (var line in lines)
        {
            print(line);
            ParseLine(line);
            yield return new WaitForSeconds(wait);
        }
    }
   
}
