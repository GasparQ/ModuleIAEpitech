﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public float radius = 0.1f;
    
    public void AddPlayer(GameObject obj)
    {
        obj.transform.SetParent(transform);
    }

    private void Update()
    {
        if (transform.childCount > 0)
        {
            if (transform.childCount == 1)
            {
                transform.GetChild(0).localPosition = Vector2.zero;
            }
            else { 
                float angle = Mathf.Deg2Rad * (360 / transform.childCount);
                for (int i = 0; i < transform.childCount; i++)
                {
                    var c = transform.GetChild(i);
                    var x = radius * Mathf.Cos(angle * i);
                    var y = radius * Mathf.Sin(angle * i);
                    c.localPosition = new Vector2(x, y);
                }
            }
        }
    }
}
