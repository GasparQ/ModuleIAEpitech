﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shadow : MonoBehaviour
{
    private SpriteRenderer sr;

    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();    
    }

    public void Activate()
    {
        StartCoroutine("FadeIn");
    }

    public void DeActivate()
    {
        StartCoroutine("FadeOut");
    }

    IEnumerator FadeIn()
    {
        while (sr.color.a < 1f)
        {
            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, sr.color.a + 0.01f);
            yield return new WaitForEndOfFrame();
        }
    }

    IEnumerator FadeOut()
    {
        while (sr.color.a > 0f)
        {
            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, sr.color.a - 0.01f);
            yield return new WaitForEndOfFrame();
        }
    }
}
