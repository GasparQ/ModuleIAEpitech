﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singer : MonoBehaviour
{
    public float distance = 1f;
    private Vector3 startPos;
    private Vector3 targetPos;
    // Start is called before the first frame update
    void Start()
    {
        startPos = transform.position;
        targetPos = startPos;
    }

    public void MoveSinger(int score)
    {
        targetPos = new Vector3(
            startPos.x + score * distance,
            startPos.y,
            startPos.z);
    }

    public void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPos, 10f * Time.deltaTime);
    }
}
