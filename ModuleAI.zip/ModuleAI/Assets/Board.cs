﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board : MonoBehaviour
{
    public Transform spawner;
    public Transform room;

    private Spawn[] spawners;
    private Shadow[] rooms;
    // Start is called before the first frame update

    private Shadow shadow = null;
    void Awake()
    {
        spawners = new Spawn[spawner.childCount];
        for (int i = 0; i < spawner.childCount; i++)
        {
            spawners[i] = spawner.GetChild(i).GetComponent<Spawn>();
        }
        rooms = new Shadow[room.childCount];
        for (int i = 0; i < room.childCount; i++)
        {
            rooms[i] = room.GetChild(i).GetComponent<Shadow>();
        }
    }

    public void MovePlayer(GameObject player, int index)
    {
        spawners[index].AddPlayer(player);
    }

    public void ActivateShadow(int index)
    {
        if (shadow)
            shadow.DeActivate();
        shadow = rooms[index];
        shadow.Activate();
    }
}
