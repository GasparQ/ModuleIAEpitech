﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{   
    public void Clean()
    {
        transform.GetChild(0).gameObject.SetActive(false);
        //transform.GetChild(2).gameObject.SetActive(true);
    }
}
